<?php
header('Content-Type: application/json');
$dbPath = '../db/counter.db';

try {
    $db = new SQLite3($dbPath);
    $db->exec('BEGIN');
    
    $db->exec('UPDATE counter SET count = 0 WHERE id = 1');
    
    // Log the reset
    $stmt = $db->prepare('INSERT INTO logs (action, new_value, note) VALUES (?, ?, ?)');
    $stmt->bindValue(1, 'reset', SQLITE3_TEXT);
    $stmt->bindValue(2, 0, SQLITE3_INTEGER);
    $stmt->bindValue(3, 'Counter reset', SQLITE3_TEXT);
    $stmt->execute();
    
    $db->exec('COMMIT');
    echo json_encode(['count' => 0]);
} catch (Exception $e) {
    if ($db) $db->exec('ROLLBACK');
    http_response_code(500);
    echo json_encode(['error' => 'Database error', 'details' => $e->getMessage()]);
}
?>
