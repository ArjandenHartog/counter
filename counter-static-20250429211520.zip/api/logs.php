<?php
header('Content-Type: application/json');
$dbPath = '../db/counter.db';

try {
    $db = new SQLite3($dbPath);
    
    // Check if logs table exists
    $tableExists = $db->querySingle("SELECT name FROM sqlite_master WHERE type='table' AND name='logs'");
    
    if (!$tableExists) {
        // Create logs table if it doesn't exist
        $db->exec('
          CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            action TEXT NOT NULL,
            new_value INTEGER NOT NULL,
            note TEXT
          )
        ');
        echo json_encode(['logs' => []]);
    } else {
        // Get logs, most recent first
        $result = $db->query('SELECT id, timestamp, action, new_value, note FROM logs ORDER BY timestamp DESC LIMIT 100');
        $logs = [];
        
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $logs[] = $row;
        }
        
        echo json_encode(['logs' => $logs]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error', 'details' => $e->getMessage()]);
}
?>
