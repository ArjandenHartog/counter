<?php
header('Content-Type: application/json');
$dbPath = '../db/counter.db';

try {
    $db = new SQLite3($dbPath);
    $db->exec('BEGIN');
    
    $db->exec('UPDATE counter SET count = count + 1 WHERE id = 1');
    
    // Get updated count
    $result = $db->query('SELECT COALESCE(count, 0) as count FROM counter WHERE id = 1');
    $row = $result->fetchArray(SQLITE3_ASSOC);
    $count = $row ? intval($row['count']) : 0;
    
    // Log the increment
    $stmt = $db->prepare('INSERT INTO logs (action, new_value, note) VALUES (?, ?, ?)');
    $stmt->bindValue(1, 'increment', SQLITE3_TEXT);
    $stmt->bindValue(2, $count, SQLITE3_INTEGER);
    $stmt->bindValue(3, 'Counter verhoogd', SQLITE3_TEXT);
    $stmt->execute();
    
    $db->exec('COMMIT');
    echo json_encode(['count' => $count]);
} catch (Exception $e) {
    if ($db) $db->exec('ROLLBACK');
    http_response_code(500);
    echo json_encode(['error' => 'Database error', 'details' => $e->getMessage()]);
}
?>
