<?php
header('Content-Type: application/json');
$dbPath = '../../db/counter.db';

try {
    $db = new SQLite3($dbPath);
    $db->exec('BEGIN');
    
    // Check if teams table exists
    $tableExists = $db->querySingle("SELECT name FROM sqlite_master WHERE type='table' AND name='teams'");
    
    if (!$tableExists) {
        // Create teams table if it doesn't exist
        $db->exec('
          CREATE TABLE IF NOT EXISTS teams (
            id INTEGER PRIMARY KEY,
            count INTEGER NOT NULL DEFAULT 0
          )
        ');
        
        // Initialize with 0 teams
        $db->exec('INSERT INTO teams (id, count) VALUES (1, 0)');
    }
    
    // Increment counter
    $db->exec('UPDATE teams SET count = count + 1 WHERE id = 1');
    
    // Get updated count
    $result = $db->query('SELECT COALESCE(count, 0) as count FROM teams WHERE id = 1');
    $row = $result->fetchArray(SQLITE3_ASSOC);
    $count = $row ? intval($row['count']) : 0;
    
    // Log the increment
    $stmt = $db->prepare('INSERT INTO logs (action, new_value, note) VALUES (?, ?, ?)');
    $stmt->bindValue(1, 'team_added', SQLITE3_TEXT);
    $stmt->bindValue(2, $count, SQLITE3_INTEGER);
    $stmt->bindValue(3, 'Team aanmelding', SQLITE3_TEXT);
    $stmt->execute();
    
    $db->exec('COMMIT');
    echo json_encode(['count' => $count]);
} catch (Exception $e) {
    if ($db) $db->exec('ROLLBACK');
    http_response_code(500);
    echo json_encode(['error' => 'Database error', 'details' => $e->getMessage()]);
}
?>
