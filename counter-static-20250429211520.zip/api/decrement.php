<?php
header('Content-Type: application/json');
$dbPath = '../db/counter.db';

try {
    $db = new SQLite3($dbPath);
    $db->exec('BEGIN');
    
    // Only decrement if count > 0
    $result = $db->query('SELECT COALESCE(count, 0) as count FROM counter WHERE id = 1');
    $row = $result->fetchArray(SQLITE3_ASSOC);
    $currentCount = $row ? intval($row['count']) : 0;
    
    if ($currentCount > 0) {
        $db->exec('UPDATE counter SET count = count - 1 WHERE id = 1');
        
        // Get updated count
        $result = $db->query('SELECT COALESCE(count, 0) as count FROM counter WHERE id = 1');
        $row = $result->fetchArray(SQLITE3_ASSOC);
        $count = $row ? intval($row['count']) : 0;
        
        // Log the decrement
        $stmt = $db->prepare('INSERT INTO logs (action, new_value, note) VALUES (?, ?, ?)');
        $stmt->bindValue(1, 'decrement', SQLITE3_TEXT);
        $stmt->bindValue(2, $count, SQLITE3_INTEGER);
        $stmt->bindValue(3, 'Counter verlaagd', SQLITE3_TEXT);
        $stmt->execute();
    } else {
        $count = 0;
    }
    
    $db->exec('COMMIT');
    echo json_encode(['count' => $count]);
} catch (Exception $e) {
    if ($db) $db->exec('ROLLBACK');
    http_response_code(500);
    echo json_encode(['error' => 'Database error', 'details' => $e->getMessage()]);
}
?>
