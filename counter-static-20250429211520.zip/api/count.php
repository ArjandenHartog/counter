<?php
header('Content-Type: application/json');
$dbPath = '../db/counter.db';

try {
    $db = new SQLite3($dbPath);
    $result = $db->query('SELECT COALESCE(count, 0) as count FROM counter WHERE id = 1');
    $row = $result->fetchArray(SQLITE3_ASSOC);
    $count = $row ? intval($row['count']) : 0;
    echo json_encode(['count' => $count]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error', 'details' => $e->getMessage()]);
}
?>
